class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg-color)] text-white">
          <div className="text-center p-6 bg-gray-800 rounded-xl">
            <h1 className="text-2xl font-bold text-red-500 mb-4">Erreur Inattendue</h1>
            <p className="text-gray-300 mb-4">Désolé, un problème est survenu.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Recharger la page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
    const [gameState, setGameState] = React.useState('setup');
    const [players, setPlayers] = React.useState([]);
    const [showRules, setShowRules] = React.useState(false);
    const [wordPair, setWordPair] = React.useState(null);
    const [round, setRound] = React.useState(1);
    const [gameResult, setGameResult] = React.useState(null);
    const [setupConfig, setSetupConfig] = React.useState(null);
    const [scores, setScores] = React.useState({});
    const [firstPlayerId, setFirstPlayerId] = React.useState(null);

    const handleStart = (playerNames, roleConfig, categoryIds, blindMode) => {
        setSetupConfig({ playerNames, roleConfig, categoryIds, blindMode });
        const pair = window.getRandomWordPair(categoryIds);
        const generatedPlayers = window.generatePlayers(playerNames, roleConfig, pair);
        
        // Pick random first player (Exclude M. White and M. Green)
        const validFirstPlayers = generatedPlayers.filter(p => p.originalRole !== window.ROLES.MR_WHITE && p.originalRole !== window.ROLES.MR_GREEN);
        const randomFirst = validFirstPlayers.length > 0 ? validFirstPlayers[Math.floor(Math.random() * validFirstPlayers.length)] : generatedPlayers[0];
        setFirstPlayerId(randomFirst.id);

        // Initialize scores for new players
        const currentScores = { ...scores };
        playerNames.forEach(name => {
            if (currentScores[name] === undefined) currentScores[name] = 0;
        });
        setScores(currentScores);
        
        setWordPair(pair);
        setPlayers(generatedPlayers);
        setGameState('reveal');
        setRound(1);
    };

    const updatePlayer = (id, updates) => {
        setPlayers(players.map(p => p.id === id ? { ...p, ...updates } : p));
    };

    const handleRevealComplete = () => {
        setGameState('play');
    };

    const processWin = (result, finalPlayers) => {
        const newScores = { ...scores };
        if (result.winningIds) {
            result.winningIds.forEach(id => {
                const p = finalPlayers.find(player => player.id === id);
                if (p) {
                    newScores[p.name] = (newScores[p.name] || 0) + 2; // +2 points for win
                }
            });
        }
        setScores(newScores);
        setGameResult(result);
        setGameState('gameover');
    };

    const handleEliminate = (playerIds, currentRound) => {
        let idsToKill = Array.isArray(playerIds) ? playerIds : [playerIds];
        
        const updatedPlayers = players.map(p => {
            if (idsToKill.includes(p.id)) {
                return { ...p, isAlive: false, diedAtRound: currentRound };
            }
            return p;
        });
        
        setPlayers(updatedPlayers);
        
        const result = window.checkWinCondition(updatedPlayers, currentRound);
        if (result.over) {
            processWin(result, updatedPlayers);
        } else {
            setRound(currentRound + 1);
        }
    };

    const handleMrWin = (result) => {
        processWin(result, players);
    };

    const handleRestart = (mode) => {
        if (mode === 'same_all' && setupConfig) {
            handleStart(setupConfig.playerNames, setupConfig.roleConfig, setupConfig.categoryIds, setupConfig.blindMode);
        } else if (mode === 'same_players') {
            setGameState('setup');
            setPlayers([]);
            setWordPair(null);
            setGameResult(null);
        } else {
            setSetupConfig(null);
            setGameState('setup');
            setPlayers([]);
            setWordPair(null);
            setGameResult(null);
            setScores({}); // Reset scores on full reset
        }
    };

    return (
        <div className="min-h-screen flex flex-col justify-between relative" data-name="app" data-file="app.js">
            {/* Header toujours visible */}
  <header className="py-4 border-b border-gray-800 bg-gray-900/50 backdrop-blur relative shrink-0">
    <div className="max-w-4xl mx-auto px-4 flex items-center justify-center gap-2 text-xl font-bold tracking-wider relative">
        
        {/* Lien Instagram à gauche */}
        <a 
            href="https://www.instagram.com/declic_std" 
            target="_blank" 
            rel="noopener noreferrer"
            className="absolute left-4 text-gray-400 hover:text-pink-400 transition-colors flex items-center gap-1.5 text-xs sm:text-sm group"
            title="Suivez Déclic Studio sur Instagram"
        >
            <svg 
                className="w-4 h-4 fill-current group-hover:scale-110 transition-transform duration-200" 
                viewBox="0 0 24 24"
            >
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            <span className="hidden sm:inline font-medium">Suivez-moi</span>
        </a>

        {/* Titre au centre */}
        <i className="icon-search text-blue-500"></i> UNDERCOVER

        {/* Bouton Règles à droite */}
        <button 
            onClick={() => setShowRules(true)}
            className="absolute right-4 text-gray-400 hover:text-white transition-colors"
            title="Règles du jeu"
        >
            <i className="icon-circle-help text-2xl"></i>
        </button>
    </div>
</header>

            {/* Contenu principal de l'application */}
            <main className="flex-1 py-8 relative z-10 flex flex-col justify-center">
                {showRules && <window.Rules onClose={() => setShowRules(false)} />}
                {gameState === 'setup' && <window.Setup onStart={handleStart} initialConfig={setupConfig} />}
                {gameState === 'reveal' && <window.RevealRole players={players} wordPair={wordPair} onRevealComplete={handleRevealComplete} updatePlayer={updatePlayer} blindMode={setupConfig?.blindMode} />}
                {gameState === 'play' && <window.GameTurn players={players} round={round} onEliminate={handleEliminate} wordPair={wordPair} onGameOver={handleMrWin} firstPlayerId={firstPlayerId} />}
                {gameState === 'gameover' && <window.GameOver result={gameResult} players={players} wordPair={wordPair} onRestart={handleRestart} scores={scores} />}
            </main>

            {/* Footer affiché UNIQUEMENT sur l'écran d'accueil (setup) et de fin de partie (gameover) */}
            {(gameState === 'setup' || gameState === 'gameover') && <window.Footer />}
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);