function Setup({ onStart, initialConfig }) {
    const [players, setPlayers] = React.useState(initialConfig?.playerNames || ['Joueur 1', 'Joueur 2', 'Joueur 3', 'Joueur 4']);
    const [categories, setCategories] = React.useState(initialConfig?.categoryIds || ['nature']);
    const [blindMode, setBlindMode] = React.useState(initialConfig?.blindMode || false);
    const [roles, setRoles] = React.useState(initialConfig?.roleConfig || {
        undercoverCount: 1,
        mrWhite: false,
        mrGreen: false,
        ange: false,
        voleur: false,
        chasseur: false,
        voyante: false
    });

    const addPlayer = () => setPlayers([...players, `Joueur ${players.length + 1}`]);
    const removePlayer = (index) => {
        if (players.length > 3) {
            setPlayers(players.filter((_, i) => i !== index));
        }
    };
    
    const updatePlayer = (index, val) => {
        const newP = [...players];
        newP[index] = val;
        setPlayers(newP);
    };

    const toggleCategory = (key) => {
        if (categories.includes(key)) {
            if (categories.length > 1) {
                setCategories(categories.filter(c => c !== key));
            }
        } else {
            setCategories([...categories, key]);
        }
    };

    const handleStart = () => {
        const totalSpecialRoles = roles.mrWhite + roles.mrGreen + roles.ange + roles.voleur + roles.chasseur + roles.voyante + roles.undercoverCount;
        if (totalSpecialRoles >= players.length) {
            alert("Il doit y avoir au moins un Civil classique ! Réduisez le nombre de rôles spéciaux ou ajoutez des joueurs.");
            return;
        }
        if (categories.length === 0) {
            alert("Veuillez sélectionner au moins une catégorie.");
            return;
        }
        onStart(players, roles, categories, blindMode);
    };

    return (
        <div className="w-full max-w-2xl mx-auto p-4 space-y-6">
            <h1 className="text-4xl font-bold text-center mb-8 flex items-center justify-center gap-3">
                <i className="icon-user-round text-blue-500"></i>
                Undercover
            </h1>

            <div className="card space-y-4">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                    <i className="icon-users"></i> Joueurs ({players.length})
                </h2>
                <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                    {players.map((p, i) => (
                        <div key={i} className="flex gap-2">
                            <input 
                                type="text" 
                                value={p} 
                                onChange={(e) => updatePlayer(i, e.target.value)}
                                className="input-field flex-grow"
                            />
                            {players.length > 3 && (
                                <button onClick={() => removePlayer(i)} className="btn btn-danger px-3">
                                    <i className="icon-trash"></i>
                                </button>
                            )}
                        </div>
                    ))}
                </div>
                <button onClick={addPlayer} className="btn btn-secondary w-full">
                    <i className="icon-plus"></i> Ajouter un joueur
                </button>
            </div>

            <div className="card space-y-4">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                    <i className="icon-list"></i> Catégories de mots (Multiples)
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {Object.entries(window.WORD_CATEGORIES).map(([key, cat]) => {
                        const isSelected = categories.includes(key);
                        return (
                            <button 
                                key={key}
                                onClick={() => toggleCategory(key)}
                                className={`p-4 rounded-xl border-2 flex flex-col items-center justify-center gap-2 transition-all relative ${isSelected ? 'border-blue-500 bg-blue-900/20' : 'border-gray-700 bg-gray-800 hover:border-gray-600'}`}
                            >
                                {isSelected && <div className="absolute top-2 right-2 text-blue-500"><i className="icon-check"></i></div>}
                                <span className="text-4xl mb-1">{cat.emoji}</span>
                                <span className="font-semibold text-sm">{cat.name}</span>
                            </button>
                        );
                    })}
                </div>
            </div>

            <div className="card space-y-4">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                    <i className="icon-settings"></i> Paramètres & Rôles
                </h2>
                
                <label className="flex items-center justify-between p-3 bg-blue-900/30 border border-blue-800 rounded cursor-pointer hover:bg-blue-900/50 transition mb-4">
                    <div className="flex flex-col">
                        <span className="font-bold text-blue-300">Jeu à l'aveugle</span>
                        <span className="text-xs text-blue-400">Les rôles Civils et Undercover ne sont pas précisés, seul le mot est affiché (les rôles spéciaux restent visibles).</span>
                    </div>
                    <input 
                        type="checkbox" 
                        checked={blindMode} 
                        onChange={(e) => setBlindMode(e.target.checked)}
                        className="w-5 h-5 text-blue-500 rounded focus:ring-blue-500 bg-gray-700 border-gray-600 ml-4"
                    />
                </label>

                <div className="flex items-center justify-between p-2 bg-gray-800 rounded">
                    <span>Nombre d'Undercover</span>
                    <div className="flex items-center gap-3">
                        <button onClick={() => setRoles({...roles, undercoverCount: Math.max(1, roles.undercoverCount - 1)})} className="btn btn-secondary px-2 py-1">-</button>
                        <span className="font-bold">{roles.undercoverCount}</span>
                        <button onClick={() => setRoles({...roles, undercoverCount: roles.undercoverCount + 1})} className="btn btn-secondary px-2 py-1">+</button>
                    </div>
                </div>

                {['mrWhite', 'mrGreen', 'ange', 'voleur', 'chasseur', 'voyante'].map(role => (
                    <label key={role} className="flex items-center justify-between p-2 bg-gray-800 rounded cursor-pointer hover:bg-gray-700 transition">
                        <span className="capitalize">{role.replace('mr', 'M. ')}</span>
                        <input 
                            type="checkbox" 
                            checked={roles[role]} 
                            onChange={(e) => setRoles({...roles, [role]: e.target.checked})}
                            className="w-5 h-5 text-blue-500 rounded focus:ring-blue-500 bg-gray-700 border-gray-600"
                        />
                    </label>
                ))}
            </div>

            <button onClick={handleStart} className="btn btn-primary w-full py-4 text-xl mt-4">
                <i className="icon-play"></i> Démarrer la partie
            </button>
        </div>
    );
}
window.Setup = Setup;