function GameTurn({ players, round, onEliminate, wordPair, onGameOver, firstPlayerId }) {
    const [selectedPlayer, setSelectedPlayer] = React.useState(null);
    const [chasseurAction, setChasseurAction] = React.useState(false);
    const [chasseurTarget, setChasseurTarget] = React.useState(null);
    const [mrAction, setMrAction] = React.useState(false);
    const [mrGuess, setMrGuess] = React.useState("");

    const alivePlayers = players.filter(p => p.isAlive);

    const handleEliminate = () => {
        if (selectedPlayer === null) return;
        
        const playerToKill = players.find(p => p.id === selectedPlayer);
        
        if (playerToKill.currentRole === window.ROLES.CHASSEUR) {
            setChasseurAction(true);
        } else if (playerToKill.currentRole === window.ROLES.MR_WHITE || playerToKill.currentRole === window.ROLES.MR_GREEN) {
            setMrAction(true);
        } else {
            onEliminate(selectedPlayer, round);
            setSelectedPlayer(null);
        }
    };

    const handleMrGuess = () => {
        const playerToKill = players.find(p => p.id === selectedPlayer);
        if (mrGuess.trim().toLowerCase() === wordPair.civil.trim().toLowerCase()) {
            onGameOver({ 
                over: true, 
                winners: [playerToKill.currentRole], 
                message: `${playerToKill.name} (${playerToKill.currentRole}) a deviné le mot des Civils ("${wordPair.civil}") et remporte la victoire !` 
            });
        } else {
            onEliminate(selectedPlayer, round);
            setSelectedPlayer(null);
            setMrAction(false);
            setMrGuess("");
        }
    };

    const handleChasseurEliminate = () => {
        if (chasseurTarget === null) return;
        // Kill both Chasseur and his target
        onEliminate([selectedPlayer, chasseurTarget], round);
        setSelectedPlayer(null);
        setChasseurAction(false);
        setChasseurTarget(null);
    };

    if (mrAction) {
        return (
            <div className="w-full max-w-2xl mx-auto p-4 space-y-6 text-center">
                <div className="card border-blue-500 border-2">
                    <h2 className="text-2xl font-bold text-blue-500 mb-4">Dernière chance !</h2>
                    <p className="mb-6"><strong>{players.find(p => p.id === selectedPlayer).name}</strong>, vous êtes sur le point d'être éliminé. Si vous devinez le mot des Civils, vous gagnez la partie !</p>
                    
                    <input 
                        type="text" 
                        value={mrGuess} 
                        onChange={(e) => setMrGuess(e.target.value)}
                        placeholder="Mot des civils"
                        className="input-field mb-6 text-center text-xl"
                    />
                    
                    <div className="flex flex-col sm:flex-row gap-3">
                        <button 
                            onClick={handleMrGuess}
                            disabled={mrGuess.trim() === ''}
                            className="btn btn-primary flex-1 py-3"
                        >
                            Tenter ma chance
                        </button>
                        <button 
                            onClick={() => {
                                onEliminate(selectedPlayer, round);
                                setSelectedPlayer(null);
                                setMrAction(false);
                                setMrGuess("");
                            }}
                            className="btn btn-danger flex-1 py-3"
                        >
                            Je ne sais pas
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    if (chasseurAction) {
        return (
            <div className="w-full max-w-2xl mx-auto p-4 space-y-6 text-center">
                <div className="card border-red-500 border-2">
                    <h2 className="text-2xl font-bold text-red-500 mb-4">Action du Chasseur !</h2>
                    <p className="mb-6"><strong>{players.find(p => p.id === selectedPlayer).name}</strong> était le Chasseur. Avant de mourir, il peut éliminer un autre joueur.</p>
                    
                    <div className="grid grid-cols-2 gap-3 mb-6">
                        {alivePlayers.filter(p => p.id !== selectedPlayer).map(p => (
                            <button
                                key={p.id}
                                onClick={() => setChasseurTarget(p.id)}
                                className={`p-4 rounded-lg border-2 transition-all ${chasseurTarget === p.id ? 'border-red-500 bg-red-900/30' : 'border-gray-700 bg-gray-800'}`}
                            >
                                {p.name}
                            </button>
                        ))}
                    </div>
                    
                    <button 
                        onClick={handleChasseurEliminate}
                        disabled={chasseurTarget === null}
                        className="btn btn-danger w-full py-3"
                    >
                        Tirer et Mourir
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="w-full max-w-2xl mx-auto p-4 space-y-6">
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold">Tour {round}</h2>
                <p className="text-gray-400 mt-2">Discutez, donnez un mot à tour de rôle, puis votez pour éliminer un joueur suspect.</p>
                {round === 1 && firstPlayerId !== undefined && (
                    <div className="mt-4 p-3 bg-blue-900/40 border border-blue-500/50 rounded-lg text-blue-300 shadow">
                        <i className="icon-mic mr-2"></i>
                        Le premier joueur à parler est : <strong>{players.find(p => p.id === firstPlayerId)?.name}</strong>
                    </div>
                )}
            </div>

            <div className="card space-y-4">
                <h3 className="text-xl font-semibold mb-4 text-center">Joueurs en vie</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {alivePlayers.map(p => (
                        <button
                            key={p.id}
                            onClick={() => setSelectedPlayer(p.id)}
                            className={`p-4 rounded-lg border-2 transition-all flex flex-col items-center gap-2 ${selectedPlayer === p.id ? 'border-red-500 bg-red-900/20' : 'border-gray-700 bg-gray-800 hover:border-gray-500'}`}
                        >
                            <i className="icon-user-round text-2xl"></i>
                            <span className="font-bold">{p.name}</span>
                        </button>
                    ))}
                </div>
            </div>

            {selectedPlayer !== null && (
                <div className="fixed bottom-0 left-0 right-0 p-4 bg-gray-900 border-t border-gray-800 shadow-2xl flex justify-center pb-20 md:pb-4">
                    <button onClick={handleEliminate} className="btn btn-danger w-full max-w-md py-4 text-lg animate-bounce">
                        <i className="icon-skull"></i> Éliminer {players.find(p => p.id === selectedPlayer).name}
                    </button>
                </div>
            )}
        </div>
    );
}
window.GameTurn = GameTurn;