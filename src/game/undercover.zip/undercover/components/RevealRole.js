function RevealRole({ players, wordPair, onRevealComplete, updatePlayer, blindMode }) {
    const [currentIndex, setCurrentIndex] = React.useState(0);
    const [step, setStep] = React.useState('pass'); // 'pass', 'reveal', 'action'
    
    // For Voleur
    const [voleurChoice, setVoleurChoice] = React.useState(null);

    // For Voyante
    const [voyanteTarget, setVoyanteTarget] = React.useState(null);

    const currentPlayer = players[currentIndex];

    const nextPlayer = () => {
        if (currentIndex < players.length - 1) {
            setCurrentIndex(currentIndex + 1);
            setStep('pass');
        } else {
            onRevealComplete();
        }
    };

    const handleSpecialAction = () => {
        if (currentPlayer.currentRole === window.ROLES.VOLEUR && voleurChoice) {
            updatePlayer(currentPlayer.id, { 
                voleurSide: voleurChoice,
                word: voleurChoice === 'Civil' ? wordPair.civil : wordPair.undercover
            });
            setStep('voleur_result');
        } else if (currentPlayer.currentRole === window.ROLES.VOYANTE && voyanteTarget !== null) {
            updatePlayer(currentPlayer.id, { hasPlayedSpecial: true });
            setStep('voyante_result');
        } else {
            nextPlayer();
        }
    };

    if (step === 'pass') {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
                <div className="card w-full max-w-md space-y-6">
                    <i className="icon-user-round text-6xl text-blue-400"></i>
                    <h2 className="text-2xl font-bold">Passez l'appareil à</h2>
                    <p className="text-4xl font-black text-blue-500">{currentPlayer.name}</p>
                    <button onClick={() => setStep('reveal')} className="btn btn-primary w-full py-3">
                        Je suis {currentPlayer.name}
                    </button>
                </div>
            </div>
        );
    }

    if (step === 'voyante_result') {
        const target = players.find(p => p.id === voyanteTarget);
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
                <div className="card w-full max-w-md space-y-6 border-purple-500 border-2">
                    <h2 className="text-2xl font-bold">Vision de la Voyante</h2>
                    <p className="text-xl">Le rôle de <strong>{target.name}</strong> est :</p>
                    <p className="text-3xl font-bold text-purple-400">{target.originalRole}</p>
                    <button onClick={nextPlayer} className="btn btn-primary w-full py-3">
                        Cacher et Suivant
                    </button>
                </div>
            </div>
        );
    }

    if (step === 'voleur_result') {
        const wordToDisplay = voleurChoice === 'Civil' ? wordPair.civil : wordPair.undercover;
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
                <div className="card w-full max-w-md space-y-6 border-pink-500 border-2">
                    <h2 className="text-2xl font-bold">Votre Mot Secret</h2>
                    <p className="text-xl text-gray-300">En tant que Voleur ({voleurChoice}), votre mot est :</p>
                    <p className="text-4xl font-bold text-blue-400 mb-6 bg-gray-800 p-4 rounded-lg">{wordToDisplay}</p>
                    <button onClick={nextPlayer} className="btn btn-primary w-full py-3">
                        J'ai compris, cacher
                    </button>
                </div>
            </div>
        );
    }

    const needsAction = currentPlayer.currentRole === window.ROLES.VOLEUR || currentPlayer.currentRole === window.ROLES.VOYANTE;

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
            <div className="card w-full max-w-md space-y-6">
                <h2 className="text-xl font-bold text-gray-400">Rôle de {currentPlayer.name}</h2>
                <div className="py-4">
                    <p className="text-sm uppercase tracking-widest text-gray-500 mb-2">Votre rôle est</p>
                    {blindMode && (currentPlayer.currentRole === window.ROLES.CIVIL || currentPlayer.currentRole === window.ROLES.UNDERCOVER) ? (
                        <p className="text-2xl font-bold text-gray-300 mb-6 italic">Civil ou Undercover</p>
                    ) : (
                        <p className="text-3xl font-black text-blue-400 mb-6">{currentPlayer.currentRole}</p>
                    )}
                    
                    {currentPlayer.word && (
                        <div className="bg-gray-800 p-4 rounded-lg mb-4">
                            <p className="text-sm text-gray-400 mb-1">Votre mot secret :</p>
                            <p className="text-2xl font-bold">{currentPlayer.word}</p>
                        </div>
                    )}
                    
                    {currentPlayer.theme && (
                        <div className="bg-gray-800 p-4 rounded-lg mb-4">
                            <p className="text-sm text-gray-400 mb-1">Le thème est :</p>
                            <p className="text-2xl font-bold">{currentPlayer.theme}</p>
                        </div>
                    )}
                    
                    {currentPlayer.currentRole === window.ROLES.MR_WHITE && (
                        <p className="text-gray-300 italic mb-4">Vous n'avez pas de mot. Essayez de deviner celui des autres et fondez-vous dans la masse !</p>
                    )}
                </div>

                {currentPlayer.currentRole === window.ROLES.VOLEUR && step === 'reveal' && (
                    <div className="space-y-4">
                        <p className="font-bold">Choisissez votre camp :</p>
                        <div className="flex gap-2">
                            <button onClick={() => setVoleurChoice('Civil')} className={`flex-1 py-2 rounded transition-colors ${voleurChoice === 'Civil' ? 'bg-blue-600 text-white' : 'bg-gray-700'}`}>Civils</button>
                            <button onClick={() => setVoleurChoice('Undercover')} className={`flex-1 py-2 rounded transition-colors ${voleurChoice === 'Undercover' ? 'bg-red-600 text-white' : 'bg-gray-700'}`}>Undercovers</button>
                        </div>
                    </div>
                )}

                {currentPlayer.currentRole === window.ROLES.VOYANTE && step === 'reveal' && (
                    <div className="space-y-4">
                        <p className="font-bold">Choisissez un joueur à sonder :</p>
                        <div className="grid grid-cols-2 gap-2">
                            {players.filter(p => p.id !== currentPlayer.id).map(p => (
                                <button 
                                    key={p.id} 
                                    onClick={() => setVoyanteTarget(p.id)}
                                    className={`py-2 rounded ${voyanteTarget === p.id ? 'bg-purple-600 text-white' : 'bg-gray-700'}`}
                                >
                                    {p.name}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                <button 
                    onClick={needsAction ? handleSpecialAction : nextPlayer} 
                    disabled={needsAction && (currentPlayer.currentRole === window.ROLES.VOLEUR ? !voleurChoice : voyanteTarget === null)}
                    className="btn btn-primary w-full py-3 mt-4"
                >
                    {needsAction ? "Valider" : "J'ai compris, cacher"}
                </button>
            </div>
        </div>
    );
}
window.RevealRole = RevealRole;