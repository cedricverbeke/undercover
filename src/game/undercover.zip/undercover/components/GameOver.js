function GameOver({ result, players, wordPair, onRestart, scores }) {
    return (
        <div className="w-full max-w-2xl mx-auto p-4 space-y-6 text-center">
            <h1 className="text-5xl font-black mb-2 flex justify-center items-center gap-3">
                <i className="icon-trophy text-yellow-500"></i> Fin de la partie
            </h1>
            <p className="text-xl text-blue-400 font-bold mb-8">{result.message}</p>

            <div className="card space-y-4 mb-8 border-yellow-600/50">
                <h3 className="text-xl font-semibold mb-2 text-yellow-500">Scores actuels</h3>
                <div className="flex flex-wrap justify-center gap-4">
                    {Object.entries(scores).sort((a, b) => b[1] - a[1]).map(([name, score]) => (
                        <div key={name} className="bg-gray-800 px-4 py-2 rounded-full flex gap-2 items-center">
                            <span className="font-bold text-white">{name}</span>
                            <span className="bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded text-sm font-black">{score} pts</span>
                        </div>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="card bg-gray-800/50">
                    <h3 className="text-gray-400 text-sm uppercase">Mot des Civils</h3>
                    <p className="text-2xl font-bold">{wordPair.civil}</p>
                </div>
                <div className="card bg-gray-800/50">
                    <h3 className="text-gray-400 text-sm uppercase">Mot des Undercovers</h3>
                    <p className="text-2xl font-bold">{wordPair.undercover}</p>
                </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-6">
                <div className="card space-y-4 flex-grow">
                    <h3 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Révélation des rôles</h3>
                    <div className="space-y-3">
                        {players.map(p => (
                            <div key={p.id} className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
                                <span className={`font-bold ${p.isAlive ? 'text-white' : 'text-gray-500 line-through'}`}>
                                    {p.name}
                                </span>
                                <div className="text-right">
                                    <span className={`px-2 py-1 rounded text-sm ${
                                        p.currentRole === window.ROLES.UNDERCOVER ? 'bg-red-900/50 text-red-300' : 
                                        p.currentRole === window.ROLES.CIVIL ? 'bg-blue-900/50 text-blue-300' : 'bg-purple-900/50 text-purple-300'
                                    }`}>
                                        {p.currentRole} {p.currentRole === window.ROLES.VOLEUR && `(${p.voleurSide})`}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

 <a 
    href="https://www.declicstudio.fr" 
    target="_blank" 
    rel="noopener noreferrer"
    className="block shrink-0 mx-auto lg:mx-0 w-48 relative group overflow-hidden rounded-xl border border-gray-700 hover:border-blue-500 transition-colors shadow-xl"
>
    {/* En-tête Publicité */}
    <div className="absolute top-0 left-0 right-0 bg-black/60 backdrop-blur text-center py-1 text-[10px] text-gray-300 font-bold tracking-widest z-10">
        CRÉÉ PAR
    </div>

    {/* Image au ratio vertical parfait */}
    <img 
        src="img/pub.jpg" 
        alt="Déclic Studio - Photographe Martinique" 
        className="w-full aspect-[2/3] object-cover group-hover:scale-105 transition-transform duration-500"
    />

    {/* Overlay texte bas */}
    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-gray-900 via-gray-900/80 to-transparent p-4 pt-12 z-10 text-center">
        <p className="font-bold text-blue-400 text-sm mb-0.5">Déclic Studio</p>
        <p className="text-xs text-gray-300">Photographe en Martinique</p>
    </div>
</a>
            </div>

            <div className="flex flex-col gap-3 mt-8">
                <button onClick={() => onRestart('same_all')} className="btn btn-primary w-full py-4 text-lg">
                    <i className="icon-rotate-cw"></i> Rejouer (Mêmes paramètres)
                </button>
                <button onClick={() => onRestart('same_players')} className="btn btn-secondary w-full py-3 text-lg">
                    <i className="icon-users"></i> Modifier les rôles (Mêmes joueurs)
                </button>
                <button onClick={() => onRestart('full_reset')} className="btn border border-gray-600 hover:bg-gray-800 text-gray-300 w-full py-3">
                    <i className="icon-power"></i> Nouvelle partie (Reset total)
                </button>
            </div>
        </div>
    );
}
window.GameOver = GameOver;
