function Rules({ onClose }) {
    return (
        <div className="fixed inset-0 z-50 bg-black/80 flex flex-col items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl relative">
                
                <div className="p-4 border-b border-gray-800 flex items-center justify-between sticky top-0 bg-gray-900 rounded-t-xl z-10">
                    <h2 className="text-2xl font-bold flex items-center gap-2 text-blue-400">
                        <i className="icon-book"></i> Règles du Jeu
                    </h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white p-2">
                        <i className="icon-x text-2xl"></i>
                    </button>
                </div>

                <div className="p-6 overflow-y-auto space-y-8 flex-grow">
                    
                    <section>
                        <h3 className="text-xl font-bold text-white mb-3">But du jeu</h3>
                        <p className="text-gray-300">
                            <strong>Les Civils</strong> doivent identifier et éliminer tous les Undercovers (et autres rôles hostiles).<br/>
                            <strong>Les Undercovers</strong> doivent survivre jusqu'à être aussi nombreux que les Civils pour prendre le contrôle.
                        </p>
                    </section>

                    <section className="space-y-4">
                        <h3 className="text-xl font-bold text-white mb-4 border-b border-gray-800 pb-2">Les Rôles</h3>
                        
                        <div className="flex gap-4 items-start">
                            <div className="bg-blue-900/50 p-2 rounded text-blue-400"><i className="icon-user"></i></div>
                            <div>
                                <h4 className="font-bold text-blue-300">Civil</h4>
                                <p className="text-gray-400 text-sm">Il reçoit le mot secret principal. Son but est de démasquer l'Undercover sans se faire éliminer par erreur.</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-red-900/50 p-2 rounded text-red-400"><i className="icon-user-round"></i></div>
                            <div>
                                <h4 className="font-bold text-red-300">Undercover</h4>
                                <p className="text-gray-400 text-sm">Il reçoit un mot secret légèrement différent. Il doit se fondre dans la masse pour ne pas être repéré, tout en essayant de deviner le mot des civils.</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-gray-800 p-2 rounded text-white"><i className="icon-ghost"></i></div>
                            <div>
                                <h4 className="font-bold text-white">M. White</h4>
                                <p className="text-gray-400 text-sm">Il ne reçoit <strong>aucun mot</strong>. S'il est éliminé, il a une dernière chance de deviner le mot des civils pour voler la victoire instantanément !</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-green-900/50 p-2 rounded text-green-400"><i className="icon-leaf"></i></div>
                            <div>
                                <h4 className="font-bold text-green-300">M. Green</h4>
                                <p className="text-gray-400 text-sm">Il ne reçoit pas de mot, mais il connait <strong>le thème</strong> du mot (ex: "Véhicule"). Comme M. White, il peut gagner en devinant le mot civil lors de son élimination.</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-yellow-900/50 p-2 rounded text-yellow-400"><i className="icon-crown"></i></div>
                            <div>
                                <h4 className="font-bold text-yellow-300">Ange</h4>
                                <p className="text-gray-400 text-sm">Son but est paradoxal : il joue avec les civils, mais <strong>s'il est éliminé au 1er tour</strong>, il gagne immédiatement la partie.</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-purple-900/50 p-2 rounded text-purple-400"><i className="icon-eye"></i></div>
                            <div>
                                <h4 className="font-bold text-purple-300">Voyante</h4>
                                <p className="text-gray-400 text-sm">Joue avec les civils. Au début de la partie, elle peut consulter le vrai rôle d'un joueur de son choix.</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-orange-900/50 p-2 rounded text-orange-400"><i className="icon-crosshair"></i></div>
                            <div>
                                <h4 className="font-bold text-orange-300">Chasseur</h4>
                                <p className="text-gray-400 text-sm">Joue avec les civils. S'il est éliminé par vote, il emporte un autre joueur dans sa tombe avant de mourir.</p>
                            </div>
                        </div>

                        <div className="flex gap-4 items-start">
                            <div className="bg-pink-900/50 p-2 rounded text-pink-400"><i className="icon-mask"></i></div>
                            <div>
                                <h4 className="font-bold text-pink-300">Voleur</h4>
                                <p className="text-gray-400 text-sm">Au début de la partie, il choisit librement de rejoindre le camp des Civils ou des Undercovers, et découvre son mot en conséquence.</p>
                            </div>
                        </div>
                    </section>
                </div>
                
                <div className="p-4 border-t border-gray-800 text-center">
                    <button onClick={onClose} className="btn btn-primary w-full py-3">J'ai compris</button>
                </div>
            </div>
        </div>
    );
}

window.Rules = Rules;