function Footer() {
    return (
   <footer class="mt-auto py-6 border-t border-[var(--card-border)] bg-[#0f172a]/80 backdrop-blur-md text-center w-full z-10">
        <div class="max-w-xl mx-auto px-4 flex flex-col gap-3">
            <p class="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Le secret d'une soirée réussie ? Le partage et les éclats de rire. 
                <br class="hidden sm:inline" />
                <a 
                    href="https://www.declicstudio.fr" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    class="inline-block mt-1.5 font-semibold text-sky-400 hover:text-sky-300 underline decoration-sky-400/40 underline-offset-4 transition-colors duration-200"
                    title="Déclic Studio - Photographe professionnel pour immortaliser vos plus beaux événements"
                >
                    Capturez vos plus beaux moments réels avec Déclic Studio - Photographe Martinique
                </a>
            </p>
            <p class="text-slate-600 text-[10px] tracking-wider uppercase mt-1">
                Undercover &copy; 2026 • Application d'ambiance et de divertissement gratuite
            </p>
        </div>
    </footer>
    );
}
window.Footer = Footer;