window.ROLES = {
    CIVIL: 'Civil',
    UNDERCOVER: 'Undercover',
    MR_WHITE: 'M. White',
    MR_GREEN: 'M. Green',
    ANGE: 'Ange',
    VOLEUR: 'Voleur',
    CHASSEUR: 'Chasseur',
    VOYANTE: 'Voyante'
};

window.generatePlayers = (playerNames, roleConfig, wordPair) => {
    let pool = [];
    
    // Add special roles
    if (roleConfig.mrWhite) pool.push(window.ROLES.MR_WHITE);
    if (roleConfig.mrGreen) pool.push(window.ROLES.MR_GREEN);
    if (roleConfig.ange) pool.push(window.ROLES.ANGE);
    if (roleConfig.voleur) pool.push(window.ROLES.VOLEUR);
    if (roleConfig.chasseur) pool.push(window.ROLES.CHASSEUR);
    if (roleConfig.voyante) pool.push(window.ROLES.VOYANTE);
    
    // Add undercover
    for (let i = 0; i < roleConfig.undercoverCount; i++) {
        pool.push(window.ROLES.UNDERCOVER);
    }
    
    // Fill rest with Civils
    while (pool.length < playerNames.length) {
        pool.push(window.ROLES.CIVIL);
    }
    
    // Shuffle pool
    pool.sort(() => Math.random() - 0.5);
    
    return playerNames.map((name, index) => {
        const role = pool[index];
        let word = '';
        let theme = '';
        
        switch (role) {
            case window.ROLES.CIVIL:
            case window.ROLES.VOYANTE:
            case window.ROLES.CHASSEUR:
            case window.ROLES.ANGE:
                word = wordPair.civil;
                break;
            case window.ROLES.UNDERCOVER:
                word = wordPair.undercover;
                break;
            case window.ROLES.VOLEUR:
                // Word is chosen during reveal
                break;
            case window.ROLES.MR_GREEN:
                theme = wordPair.theme;
                break;
            case window.ROLES.MR_WHITE:
                // No word
                break;
        }
        
        return {
            id: index,
            name,
            originalRole: role,
            currentRole: role,
            word,
            theme,
            isAlive: true,
            hasPlayedSpecial: false
        };
    });
};

window.checkWinCondition = (players, roundNumber) => {
    const alive = players.filter(p => p.isAlive);
    const deadThisRound = players.filter(p => !p.isAlive && p.diedAtRound === roundNumber);
    
    // Check Ange win
    const ange = deadThisRound.find(p => p.currentRole === window.ROLES.ANGE);
    if (ange && roundNumber === 1) {
        return { over: true, winners: ['Ange'], winningIds: [ange.id], message: "L'Ange a été éliminé au premier tour et remporte la partie !" };
    }
    
    const isCivil = (p) => p.currentRole !== window.ROLES.UNDERCOVER && !(p.currentRole === window.ROLES.VOLEUR && p.voleurSide === 'Undercover');
    const isUndercover = (p) => p.currentRole === window.ROLES.UNDERCOVER || (p.currentRole === window.ROLES.VOLEUR && p.voleurSide === 'Undercover');

    const civilsAlive = alive.filter(isCivil).length;
    const undercoverAlive = alive.filter(isUndercover).length;
    
    if (undercoverAlive === 0) {
        const civilIds = players.filter(isCivil).map(p => p.id);
        return { over: true, winners: ['Civils'], winningIds: civilIds, message: "Tous les Undercovers ont été éliminés. Les Civils gagnent !" };
    }
    
    if (undercoverAlive >= civilsAlive) {
        const undercoverIds = players.filter(isUndercover).map(p => p.id);
        return { over: true, winners: ['Undercover'], winningIds: undercoverIds, message: "Les Undercovers sont aussi nombreux que les Civils. Ils prennent le contrôle et gagnent !" };
    }
    
    return { over: false };
};