# Undercover Game Project

Ce projet est une adaptation web du célèbre jeu de société "Undercover", avec un design sombre et moderne et l'intégration de rôles spéciaux avancés (M. White, M. Green, Ange, Voleur, Chasseur, Voyante).

## Main components
- `Setup`: Configuration des joueurs et des rôles.
- `RevealRole`: Phase de passage d'appareil pour découvrir son rôle secrètement.
- `GameTurn`: Phase de vote et d'élimination, incluant les actions spéciales (ex: Chasseur).
- `GameOver`: Bilan de la partie et révélation des mots.

## Nouvelles Fonctionnalités
- Support de multiples catégories de mots simultanément.
- Système de score qui persiste entre les parties, récompensant les gagnants (+2 pts).
- Mode "Jeu à l'aveugle" cachant les rôles Civils et Undercover au moment de la révélation.
- Désignation aléatoire du premier joueur au Tour 1 (excluant M. White et M. Green).
- Trois modes de redémarrage de partie: mêmes paramètres, conserver les joueurs uniquement, ou reset total (qui efface les scores).
- Fenêtre modale des règles accessible depuis l'icône dans l'entête.
- Tous les rôles spéciaux sont comptabilisés avec les Civils pour les conditions de victoire, à l'exception du Voleur qui peut choisir son camp en début de partie (puis reçoit son mot en fonction).
- M. White et M. Green ont une chance de deviner le mot civil lors de leur élimination pour remporter immédiatement la partie.

## Règles de maintenance
- Lors de l'ajout de nouveaux rôles, mettre à jour `utils/gameLogic.js`.
- Lors de l'ajout de mots, mettre à jour `utils/words.js`.
- Toujours vérifier ce `README.md` lors d'une mise à jour majeure pour le tenir à jour.