When maintaining the Voleur role logic
- The Voleur (Thief) must be able to choose their side (Civil or Undercover) during the RevealRole phase.
- Their word is determined by their chosen side.
- The `checkWinCondition` logic must account for the Voleur's chosen side (`voleurSide`).